import React, { useState } from "react";
import { User } from "../types";
import { LogIn, UserPlus, X, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export default function AuthModal({ isOpen, onClose, onLoginSuccess }: AuthModalProps) {
  const [isSignUp, setIsSignUp] = useState(true);
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [avatarSeed, setAvatarSeed] = useState("avatar-1");
  const [error, setError] = useState("");

  const avatarSeeds = [
    { id: "avatar-1", label: "👷‍♂️", color: "bg-amber-100" },
    { id: "avatar-2", label: "👩‍⚕️", color: "bg-teal-100" },
    { id: "avatar-3", label: "🧑‍💻", color: "bg-blue-100" },
    { id: "avatar-4", label: "👩‍🌾", color: "bg-emerald-100" },
    { id: "avatar-5", label: "👨‍🚒", color: "bg-rose-100" },
    { id: "avatar-6", label: "👩‍🎓", color: "bg-indigo-100" },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email) {
      setError("Please enter your email address.");
      return;
    }

    if (isSignUp && !username) {
      setError("Please choose a username.");
      return;
    }

    // Save/Get from localStorage for mock accounts
    const savedUsersKey = "civiclens_users_db";
    const existingUsers = JSON.parse(localStorage.getItem(savedUsersKey) || "[]") as User[];

    let user: User | undefined;

    if (isSignUp) {
      // Check if user already exists
      const userExists = existingUsers.some((u) => u.email.toLowerCase() === email.toLowerCase());
      if (userExists) {
        setError("An account with this email already exists. Please log in instead.");
        return;
      }

      const newUser: User = {
        email: email.toLowerCase(),
        username: username.trim(),
        avatarSeed,
      };

      existingUsers.push(newUser);
      localStorage.setItem(savedUsersKey, JSON.stringify(existingUsers));
      user = newUser;
    } else {
      // Login check
      user = existingUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
      if (!user) {
        // Auto-create to prevent frustration
        const autoUsername = email.split("@")[0] || "Citizen";
        const newUser: User = {
          email: email.toLowerCase(),
          username: autoUsername,
          avatarSeed: "avatar-1",
        };
        existingUsers.push(newUser);
        localStorage.setItem(savedUsersKey, JSON.stringify(existingUsers));
        user = newUser;
      }
    }

    localStorage.setItem("civiclens_current_user", JSON.stringify(user));
    onLoginSuccess(user);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.2 }}
            id="auth-modal-card"
            className="w-full max-w-md overflow-hidden bg-white rounded-2xl shadow-xl border border-slate-100"
          >
            {/* Header */}
            <div className="relative px-6 py-5 bg-gradient-to-r from-emerald-600 to-teal-700 text-white">
              <button
                onClick={onClose}
                id="close-auth-modal"
                className="absolute top-4 right-4 p-1 rounded-full bg-black/10 hover:bg-black/20 text-white transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </button>
              <h3 className="text-xl font-semibold tracking-tight">
                {isSignUp ? "Join CivicLens AI" : "Welcome Back"}
              </h3>
              <p className="mt-1 text-xs text-emerald-100">
                {isSignUp 
                  ? "Create a citizen profile to report issues and upvote neighborhood fixes." 
                  : "Sign in with your email to view reports and participate."}
              </p>
            </div>

            {/* Content */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div id="auth-error-banner" className="flex items-start gap-2.5 p-3 text-xs text-rose-700 bg-rose-50 border border-rose-100 rounded-lg">
                  <ShieldAlert size={16} className="shrink-0 mt-0.5 text-rose-500" />
                  <span>{error}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-700" htmlFor="auth-email">
                  Email Address
                </label>
                <input
                  id="auth-email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm text-slate-900 placeholder-slate-400 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition"
                  required
                />
              </div>

              {isSignUp && (
                <>
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-slate-700" htmlFor="auth-username">
                      Username / Nickname
                    </label>
                    <input
                      id="auth-username"
                      type="text"
                      placeholder="e.g., JaneDoe_1"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm text-slate-900 placeholder-slate-400 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition"
                      required={isSignUp}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-700">
                      Choose Your Citizen Badge
                    </label>
                    <div className="grid grid-cols-6 gap-2">
                      {avatarSeeds.map((seed) => (
                        <button
                          key={seed.id}
                          type="button"
                          onClick={() => setAvatarSeed(seed.id)}
                          className={`flex items-center justify-center p-2.5 text-xl rounded-xl border transition-all ${
                            avatarSeed === seed.id
                              ? "border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/20 scale-105"
                              : "border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-slate-100"
                          }`}
                        >
                          {seed.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              <button
                type="submit"
                id="submit-auth-form"
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl cursor-pointer shadow-sm hover:shadow-md transition-all active:scale-[0.98]"
              >
                {isSignUp ? (
                  <>
                    <UserPlus size={16} />
                    Register & Start Reporting
                  </>
                ) : (
                  <>
                    <LogIn size={16} />
                    Sign In
                  </>
                )}
              </button>

              <div className="pt-2 border-t border-slate-100 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setError("");
                  }}
                  className="text-xs font-medium text-emerald-600 hover:text-emerald-700 hover:underline"
                >
                  {isSignUp 
                    ? "Already have an account? Sign In" 
                    : "New to CivicLens AI? Create an account"}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
