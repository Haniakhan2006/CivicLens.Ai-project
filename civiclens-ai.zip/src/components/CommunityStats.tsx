import { Stats } from "../types";
import { Landmark, ThumbsUp, ShieldCheck, ShieldAlert, CheckCircle2 } from "lucide-react";

interface CommunityStatsProps {
  stats: Stats;
}

export default function CommunityStats({ stats }: CommunityStatsProps) {
  const statItems = [
    {
      id: "stat-total-issues",
      label: "Citizen Reports",
      value: stats.totalIssues,
      desc: `${stats.resolvedCount} of ${stats.totalIssues} cases resolved`,
      icon: ShieldAlert,
      color: "text-amber-600 bg-amber-50 border border-amber-100",
    },
    {
      id: "stat-total-votes",
      label: "Community Upvotes",
      value: stats.totalVotes,
      desc: "Upvotes expressing priority",
      icon: ThumbsUp,
      color: "text-blue-600 bg-blue-50 border border-blue-100",
    },
    {
      id: "stat-total-confirmations",
      label: "Physical Confirmations",
      value: stats.totalConfirmations,
      desc: "Double-checked on the field",
      icon: ShieldCheck,
      color: "text-indigo-600 bg-indigo-50 border border-indigo-100",
    },
    {
      id: "stat-impact-score",
      label: "Total Community Impact",
      value: stats.totalImpactScore,
      desc: "Severity weights + verification math",
      icon: Landmark,
      color: "text-emerald-600 bg-emerald-50 border border-emerald-100",
    },
  ];

  return (
    <div id="community-stats-grid" className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      {statItems.map((item) => {
        const Icon = item.icon;
        return (
          <div
            key={item.id}
            id={item.id}
            className="flex items-start gap-3 p-4 bg-white rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-all"
          >
            <div className={`p-2 rounded-xl shrink-0 ${item.color}`}>
              <Icon size={18} />
            </div>
            <div className="min-w-0">
              <span className="block text-xs font-medium text-slate-500 uppercase tracking-wider">{item.label}</span>
              <span className="block text-xl font-bold text-slate-900 mt-0.5">{item.value}</span>
              <span className="block text-[10px] text-slate-400 mt-0.5 truncate">{item.desc}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
