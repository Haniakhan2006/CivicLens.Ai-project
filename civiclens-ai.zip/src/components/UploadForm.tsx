import React, { useState, useRef, useEffect } from "react";
import { Sparkles, UploadCloud, MapPin, AlertCircle, RotateCcw, Check, BrainCircuit } from "lucide-react";
import { User, AIAnalysis, SeverityLevel } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface UploadFormProps {
  currentUser: User | null;
  onOpenAuth: () => void;
  onSubmitIssue: (issueData: {
    title: string;
    description: string;
    image: string;
    category: string;
    severity: SeverityLevel;
    location: string;
    aiAnalysis?: AIAnalysis;
  }) => void;
}

const CATEGORIES = [
  "Roads & Asphalt",
  "Sanitation & Waste",
  "Street Lighting",
  "Public Parks",
  "Water & Sewer",
  "Safety & Hazards",
  "Public Facilities",
  "Other"
];

const SEVERITIES: SeverityLevel[] = ["Low", "Medium", "High"];

export default function UploadForm({ currentUser, onOpenAuth, onSubmitIssue }: UploadFormProps) {
  const [dragActive, setDragActive] = useState(false);
  const [image, setImage] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Roads & Asphalt");
  const [severity, setSeverity] = useState<SeverityLevel>("Medium");
  const [location, setLocation] = useState("");
  const [aiAnalysisResult, setAiAnalysisResult] = useState<AIAnalysis | undefined>(undefined);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dynamic analysis loader message list
  const loaderMessages = [
    "Uploading secure visual frame...",
    "Gemini is analyzing structural pavement and surrounding safety elements...",
    "Measuring defect hazard and severity ranking...",
    "Formulating action recommendations for local city departments...",
    "Finalizing urban category tags and public health factors..."
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAnalyzing) {
      interval = setInterval(() => {
        setAnalysisProgress((prev) => {
          if (prev >= 4) return 0;
          return prev + 1;
        });
      }, 2500);
    } else {
      setAnalysisProgress(0);
    }
    return () => clearInterval(interval);
  }, [isAnalyzing]);

  // Handle Drag Events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  // Process File Helper
  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file (PNG, JPG, or WEBP).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64Str = e.target?.result as string;
      setImage(base64Str);
      setImageMimeType(file.type);
      setError(null);
      // Run AI auto-trigger analysis or prompt them to run it
    };
    reader.onerror = () => {
      setError("Failed to read image file.");
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  // Run Gemini Analysis
  const runAIAnalysis = async () => {
    if (!image || !imageMimeType) return;
    setIsAnalyzing(true);
    setError(null);

    try {
      const response = await fetch("/api/analyze-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          base64Image: image,
          mimeType: imageMimeType,
        }),
      });

      if (!response.ok) {
        throw new Error("Server error occurred during AI image processing.");
      }

      const analysis: AIAnalysis = await response.json();
      
      // Update form fields with AI analysis
      setTitle(analysis.title || "");
      setDescription(analysis.description || "");
      setCategory(analysis.category || "Roads & Asphalt");
      setSeverity(analysis.severity || "Medium");
      setAiAnalysisResult(analysis);
    } catch (err: any) {
      console.error(err);
      setError("AI Analysis failed. You can still fill out the form manually.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Geolocation trigger
  const requestLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // Format coordinates for simplicity
          const lat = position.coords.latitude.toFixed(5);
          const lng = position.coords.longitude.toFixed(5);
          setLocation(`Lat: ${lat}, Lng: ${lng}`);
        },
        () => {
          setError("Could not retrieve current location. Please type manually.");
        }
      );
    } else {
      setError("Geolocation is not supported by your browser.");
    }
  };

  // Reset form
  const resetForm = () => {
    setImage(null);
    setImageMimeType(null);
    setTitle("");
    setDescription("");
    setCategory("Roads & Asphalt");
    setSeverity("Medium");
    setLocation("");
    setAiAnalysisResult(undefined);
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!title || !category || !severity || !location || !image) {
      setError("Please make sure an image is uploaded and all required fields are filled.");
      return;
    }

    onSubmitIssue({
      title: title.trim(),
      description: description.trim(),
      image,
      category,
      severity,
      location: location.trim(),
      aiAnalysis: aiAnalysisResult
    });

    // Reset after submit
    resetForm();
  };

  return (
    <div id="upload-form-panel" className="bg-white rounded-2xl border border-slate-100 p-6 shadow-xs relative">
      <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 mb-4">
        <Sparkles size={18} className="text-emerald-600 shrink-0" />
        Report a New Issue
      </h3>

      {error && (
        <div id="form-error-banner" className="flex items-start gap-2.5 p-3 mb-4 text-xs text-rose-700 bg-rose-50 border border-rose-100 rounded-xl">
          <AlertCircle size={16} className="shrink-0 mt-0.5 text-rose-500" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Image upload widget */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-700">Issue Photo *</label>
          
          <AnimatePresence mode="wait">
            {!image ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={triggerFileSelect}
                id="drag-and-drop-zone"
                className={`relative flex flex-col items-center justify-center border-2 border-dashed rounded-2xl py-10 px-4 cursor-pointer transition-all text-center ${
                  dragActive 
                    ? "border-emerald-500 bg-emerald-50/20" 
                    : "border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-slate-100/50"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleChange}
                  className="hidden"
                />
                <UploadCloud size={32} className="text-slate-400 mb-2.5" />
                <span className="text-sm font-semibold text-slate-700">Drag & drop your photo</span>
                <span className="text-xs text-slate-400 mt-1">or click to browse from device</span>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 group aspect-video flex items-center justify-center"
              >
                <img
                  src={image}
                  alt="Civic issue preview"
                  className="object-contain w-full h-full max-h-[220px]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Image controls overlay */}
                <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-3 transition-opacity">
                  <button
                    type="button"
                    onClick={resetForm}
                    className="p-2 bg-white/20 hover:bg-white/35 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 backdrop-blur-xs transition cursor-pointer"
                  >
                    <RotateCcw size={14} />
                    Replace
                  </button>

                  {!aiAnalysisResult && !isAnalyzing && (
                    <button
                      type="button"
                      onClick={runAIAnalysis}
                      className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                    >
                      <Sparkles size={14} />
                      Analyze with AI
                    </button>
                  )}
                </div>

                {/* Status Badges */}
                {aiAnalysisResult && (
                  <div className="absolute top-3 left-3 bg-emerald-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                    <BrainCircuit size={11} />
                    AI Analyzed
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* AI Analyzing Loading State */}
        <AnimatePresence>
          {isAnalyzing && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl space-y-3 overflow-hidden"
            >
              <div className="flex items-center gap-3">
                <div className="relative flex items-center justify-center">
                  <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
                  <Sparkles size={12} className="absolute text-emerald-600 animate-pulse" />
                </div>
                <span className="text-xs font-bold text-emerald-800">CivicLens AI Vision Active</span>
              </div>
              <motion.p
                key={analysisProgress}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-[11px] text-emerald-600 font-medium"
              >
                {loaderMessages[analysisProgress]}
              </motion.p>
              <div className="w-full bg-emerald-100 rounded-full h-1">
                <motion.div
                  className="bg-emerald-600 h-1 rounded-full"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 12, ease: "linear" }}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Form fields (Only visible when image is loaded or if user wants to type anyway) */}
        {image && !isAnalyzing && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="space-y-4 pt-1"
          >
            {/* Title field */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700" htmlFor="issue-title">
                Issue Title *
              </label>
              <input
                id="issue-title"
                type="text"
                placeholder="Give the issue a concise title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition"
                required
              />
            </div>

            {/* Description field */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700" htmlFor="issue-desc">
                Description / Community Impact
              </label>
              <textarea
                id="issue-desc"
                rows={3}
                placeholder="Describe what is broken and how it affects the neighborhood"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3.5 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition resize-none"
              />
            </div>

            {/* Category and Severity Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700" htmlFor="issue-category">
                  Category *
                </label>
                <select
                  id="issue-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition cursor-pointer"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">Severity *</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {SEVERITIES.map((sev) => {
                    const isActive = severity === sev;
                    const styles = {
                      Low: isActive ? "bg-emerald-500 text-white border-emerald-500" : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100",
                      Medium: isActive ? "bg-amber-500 text-white border-amber-500" : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100",
                      High: isActive ? "bg-rose-500 text-white border-rose-500" : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                    };
                    return (
                      <button
                        key={sev}
                        type="button"
                        onClick={() => setSeverity(sev)}
                        className={`py-2 px-1 text-center text-xs font-semibold rounded-xl border transition-all cursor-pointer ${styles[sev]}`}
                      >
                        {sev}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Location field with click to pin */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700" htmlFor="issue-location">
                Incident Location *
              </label>
              <div className="relative">
                <input
                  id="issue-location"
                  type="text"
                  placeholder="Street address, intersection, or coordinates"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full pl-3.5 pr-10 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition"
                  required
                />
                <button
                  type="button"
                  onClick={requestLocation}
                  className="absolute top-1/2 right-2.5 -translate-y-1/2 p-1 text-slate-400 hover:text-emerald-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                  title="Detect current location"
                >
                  <MapPin size={16} />
                </button>
              </div>
            </div>

            {/* AI Action item view (ReadOnly for reference) */}
            {aiAnalysisResult && (
              <div id="ai-recommended-action" className="p-3 bg-emerald-50/50 border border-emerald-100/50 rounded-xl text-xs space-y-1">
                <span className="font-bold text-emerald-800 flex items-center gap-1">
                  <BrainCircuit size={13} />
                  AI Suggested Dispatch Action
                </span>
                <p className="text-slate-600 font-medium italic">
                  "{aiAnalysisResult.actionRequired}"
                </p>
              </div>
            )}

            {/* Buttons */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={resetForm}
                className="flex-1 py-2 px-4 text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
              >
                Clear Form
              </button>

              <button
                type="submit"
                id="submit-issue-btn"
                className="flex-2 py-2 px-4 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm hover:shadow-md transition active:scale-98 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {currentUser ? (
                  <>
                    <Check size={14} />
                    File Civic Report
                  </>
                ) : (
                  "Login to Report Issue"
                )}
              </button>
            </div>
          </motion.div>
        )}
      </form>
    </div>
  );
}
