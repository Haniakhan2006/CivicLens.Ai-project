import { useState } from "react";
import { CivicIssue, SeverityLevel, User } from "../types";
import { 
  Search, Filter, ArrowUpDown, ThumbsUp, MapPin, 
  Calendar, User as UserIcon, CheckCircle2, ChevronDown, ChevronUp, 
  BrainCircuit, Star, Flame, Clock, RefreshCw, ShieldCheck
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface IssueDashboardProps {
  issues: CivicIssue[];
  currentUser: User | null;
  onUpvote: (issueId: string) => void;
  onConfirm: (issueId: string) => void;
  onToggleResolve: (issueId: string) => void;
  onOpenAuth: () => void;
}

export default function IssueDashboard({
  issues,
  currentUser,
  onUpvote,
  onConfirm,
  onToggleResolve,
  onOpenAuth,
}: IssueDashboardProps) {
  // Filters & State
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedSeverity, setSelectedSeverity] = useState("All");
  const [selectedStatus, setSelectedStatus] = useState("All"); // All, Open, Resolved
  const [sortBy, setSortBy] = useState<"impact" | "votes" | "date">("impact");
  const [expandedAiId, setExpandedAiId] = useState<string | null>(null);
  const [showFormulaGuide, setShowFormulaGuide] = useState(true);

  // Extract unique categories
  const categories = ["All", ...Array.from(new Set(issues.map((i) => i.category)))];

  // Map severity badges
  const getSeverityBadge = (level: SeverityLevel) => {
    const styles = {
      Low: "bg-emerald-50 text-emerald-700 border-emerald-100",
      Medium: "bg-amber-50 text-amber-700 border-amber-100",
      High: "bg-rose-50 text-rose-700 border-rose-100",
    };
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border ${styles[level]}`}>
        {level} Priority
      </span>
    );
  };

  // Format date helper
  const formatDate = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Recently";
    }
  };

  // Filter & Sort Logic
  const filteredIssues = issues
    .filter((issue) => {
      const matchesSearch =
        issue.title.toLowerCase().includes(search.toLowerCase()) ||
        issue.description.toLowerCase().includes(search.toLowerCase()) ||
        issue.location.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = selectedCategory === "All" || issue.category === selectedCategory;
      const matchesSeverity = selectedSeverity === "All" || issue.severity === selectedSeverity;
      const matchesStatus =
        selectedStatus === "All" ||
        (selectedStatus === "Resolved" && issue.isResolved) ||
        (selectedStatus === "Open" && !issue.isResolved);

      return matchesSearch && matchesCategory && matchesSeverity && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === "impact") {
        return b.impactScore - a.impactScore;
      } else if (sortBy === "votes") {
        return b.votes - a.votes;
      } else {
        return new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime();
      }
    });

  return (
    <div id="issue-dashboard" className="space-y-4">
      {/* Scoring Formula Guide Panel */}
      <div id="scoring-formula-guide" className="bg-gradient-to-br from-indigo-950 to-slate-900 rounded-2xl p-5 text-white shadow-xs border border-indigo-900/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/10 rounded-xl text-indigo-300 border border-indigo-500/20">
              <Flame size={16} className="text-orange-400 shrink-0 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-100">Civic Priority Scoring Logic</h3>
              <p className="text-[11px] text-slate-400 font-medium">How community issues are ranked & prioritized</p>
            </div>
          </div>
          <button 
            onClick={() => setShowFormulaGuide(!showFormulaGuide)}
            className="text-[10px] bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-md text-slate-300 hover:text-white font-semibold transition border border-white/10 cursor-pointer"
          >
            {showFormulaGuide ? "Hide Formula" : "Show Formula"}
          </button>
        </div>

        <AnimatePresence>
          {showFormulaGuide && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden mt-4 pt-4 border-t border-white/5 space-y-4"
            >
              {/* Formula Banner */}
              <div className="bg-slate-950/50 p-3.5 rounded-xl border border-white/5 flex flex-col md:flex-row items-center justify-between gap-3">
                <div className="text-center md:text-left">
                  <span className="text-[9px] uppercase font-black text-indigo-400 tracking-wider">Community Impact Equation</span>
                  <div className="text-base font-black font-mono text-emerald-400 mt-0.5">
                    Impact Score = (S × 20) + (V × 10) + (C × 15)
                  </div>
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded-md font-bold border border-emerald-500/20">
                    S = Severity (1-3)
                  </span>
                  <span className="text-[10px] bg-blue-500/10 text-blue-300 px-2 py-0.5 rounded-md font-bold border border-blue-500/20">
                    V = Upvotes
                  </span>
                  <span className="text-[10px] bg-indigo-500/10 text-indigo-300 px-2 py-0.5 rounded-md font-bold border border-indigo-500/20">
                    C = Confirmations
                  </span>
                </div>
              </div>

              {/* Details explanation */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-medium text-slate-300">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">1. Parameter Weightings</span>
                  <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300">
                    <li><strong className="text-white">Severity (S):</strong> Low=1, Medium=2, High=3</li>
                    <li><strong className="text-white">Upvotes (V):</strong> +10 points per vote</li>
                    <li><strong className="text-white">Confirmations (C):</strong> +15 points per check</li>
                  </ul>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">2. Output Priority Levels</span>
                  <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300">
                    <li><strong className="text-emerald-400">Low Priority:</strong> Score &lt; 50</li>
                    <li><strong className="text-amber-400">Medium Priority:</strong> Score 50 - 99</li>
                    <li><strong className="text-rose-400 font-bold">High Priority:</strong> Score &ge; 100</li>
                  </ul>
                </div>

                <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">Why Confirmations?</span>
                  <p className="text-[10px] leading-relaxed text-slate-400 mt-1">
                    Confirmations carry a <strong className="text-white">1.5x higher</strong> weight than upvotes. They certify physical witnesses verified the hazard in person.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Search & Filters Panel */}
      <div id="dashboard-filters-panel" className="bg-white rounded-2xl border border-slate-100 p-4 shadow-xs space-y-3">
        {/* Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search reports by title, description or location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white transition"
          />
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        </div>

        {/* Filter selectors row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-1 text-xs">
          {/* Category Filter */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Category</span>
            <div className="relative">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden text-slate-700 font-medium cursor-pointer"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Severity Filter */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Severity</span>
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden text-slate-700 font-medium cursor-pointer"
            >
              <option value="All">All Severities</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Status</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden text-slate-700 font-medium cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="Open">Open Cases</option>
              <option value="Resolved">Resolved Cases</option>
            </select>
          </div>

          {/* Sort Selector */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Sort By</span>
            <div className="flex bg-slate-50 border border-slate-200 rounded-lg p-0.5">
              <button
                onClick={() => setSortBy("impact")}
                className={`flex-1 py-1 text-center font-bold rounded-md transition ${
                  sortBy === "impact" ? "bg-white text-emerald-600 shadow-xs" : "text-slate-500 hover:text-slate-700"
                }`}
                title="Sort by Community Impact Score"
              >
                <Flame size={12} className="inline mr-1" />
                Score
              </button>
              <button
                onClick={() => setSortBy("votes")}
                className={`flex-1 py-1 text-center font-bold rounded-md transition ${
                  sortBy === "votes" ? "bg-white text-emerald-600 shadow-xs" : "text-slate-500 hover:text-slate-700"
                }`}
                title="Sort by Upvote Count"
              >
                <ThumbsUp size={11} className="inline mr-1" />
                Votes
              </button>
              <button
                onClick={() => setSortBy("date")}
                className={`flex-1 py-1 text-center font-bold rounded-md transition ${
                  sortBy === "date" ? "bg-white text-emerald-600 shadow-xs" : "text-slate-500 hover:text-slate-700"
                }`}
                title="Sort by Reported Date"
              >
                <Clock size={12} className="inline mr-1" />
                Date
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Issues List Container */}
      <div id="dashboard-issue-list" className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Displaying {filteredIssues.length} of {issues.length} Issues
          </span>
        </div>

        <AnimatePresence mode="popLayout">
          {filteredIssues.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              id="empty-issues-placeholder"
              className="bg-white rounded-2xl border border-slate-100 p-12 text-center shadow-xs"
            >
              <div className="inline-flex p-3 bg-slate-50 border border-slate-100 rounded-2xl text-slate-400 mb-4">
                <Search size={28} />
              </div>
              <h4 className="text-sm font-bold text-slate-800">No matching reports found</h4>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Try widening your search terms or adjusting the category and severity filters.
              </p>
            </motion.div>
          ) : (
            filteredIssues.map((issue) => {
              const hasUpvoted = currentUser ? issue.upvotedBy?.includes(currentUser.email) : false;
              const hasConfirmed = currentUser ? issue.confirmedBy?.includes(currentUser.email) : false;
              const isExpanded = expandedAiId === issue.id;

              // Priority mapping based on formula logic
              const computedPriority = (() => {
                if (issue.impactScore >= 100) {
                  return { label: "High Priority", badge: "bg-rose-500/10 text-rose-600 border-rose-200" };
                }
                if (issue.impactScore >= 50) {
                  return { label: "Medium Priority", badge: "bg-amber-500/10 text-amber-600 border-amber-200" };
                }
                return { label: "Low Priority", badge: "bg-slate-500/10 text-slate-600 border-slate-200" };
              })();

              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  key={issue.id}
                  id={`issue-card-${issue.id}`}
                  className={`bg-white rounded-2xl border shadow-xs hover:shadow-md transition-all overflow-hidden ${
                    issue.isResolved ? "border-slate-100 bg-slate-50/40" : "border-slate-100"
                  }`}
                >
                  <div className="p-5 flex flex-col sm:flex-row gap-5">
                    {/* Thumbnail / Image container */}
                    <div className="w-full sm:w-40 h-28 shrink-0 rounded-xl overflow-hidden border border-slate-150 relative bg-slate-900 flex items-center justify-center">
                      <img
                        src={issue.image}
                        alt={issue.title}
                        className={`w-full h-full object-cover ${issue.isResolved ? "opacity-60 grayscale-[40%]" : ""}`}
                        referrerPolicy="no-referrer"
                      />
                      {/* Category tag */}
                      <span className="absolute top-2 left-2 bg-slate-900/75 text-white text-[9px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
                        {issue.category}
                      </span>
                    </div>

                    {/* Meta and Body Details */}
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="space-y-1">
                          <h4 className={`text-base font-bold leading-tight ${
                            issue.isResolved ? "text-slate-500 line-through" : "text-slate-800"
                          }`}>
                            {issue.title}
                          </h4>
                          {/* Reporter line */}
                          <div className="flex items-center gap-3 text-xs text-slate-400">
                            <span className="flex items-center gap-1">
                              <UserIcon size={12} className="shrink-0" />
                              {issue.reporterName}
                            </span>
                            <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                            <span className="flex items-center gap-1">
                              <Calendar size={12} className="shrink-0" />
                              {formatDate(issue.reportedAt)}
                            </span>
                          </div>
                        </div>

                        {/* Badges alignment */}
                        <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                          {getSeverityBadge(issue.severity)}
                          
                          {/* Computed Priority Badge */}
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border ${computedPriority.badge}`}>
                            {computedPriority.label}
                          </span>

                          {issue.isResolved && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border border-emerald-100 bg-emerald-50 text-emerald-700">
                              Resolved
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Description */}
                      <p className={`text-xs leading-relaxed ${issue.isResolved ? "text-slate-400" : "text-slate-600"}`}>
                        {issue.description}
                      </p>

                      {/* Location line */}
                      <div className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                        <MapPin size={13} className="text-slate-400 shrink-0" />
                        <span className="truncate">{issue.location}</span>
                      </div>

                      {/* Footer Actions */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-50 text-xs">
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Upvote Button */}
                          <button
                            onClick={() => {
                              if (!currentUser) onOpenAuth();
                              else onUpvote(issue.id);
                            }}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-bold transition cursor-pointer ${
                              hasUpvoted
                                ? "bg-blue-50 border-blue-200 text-blue-600 ring-2 ring-blue-500/10"
                                : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                            }`}
                            title={hasUpvoted ? "Remove upvote" : "Upvote this civic report (+10 pts)"}
                          >
                            <ThumbsUp size={13} className={hasUpvoted ? "fill-blue-500 text-blue-600" : ""} />
                            <span>{issue.votes || 0} Votes</span>
                          </button>

                          {/* Physical Confirmation Button */}
                          <button
                            onClick={() => {
                              if (!currentUser) onOpenAuth();
                              else onConfirm(issue.id);
                            }}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-bold transition cursor-pointer ${
                              hasConfirmed
                                ? "bg-indigo-50 border-indigo-200 text-indigo-600 ring-2 ring-indigo-500/10"
                                : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                            }`}
                            title={hasConfirmed ? "Retract confirmation" : "Confirm physical existence (+15 pts)"}
                          >
                            <ShieldCheck size={13} className={hasConfirmed ? "fill-indigo-500 text-indigo-600" : ""} />
                            <span>{issue.confirmations || 0} Confirms</span>
                          </button>

                          {/* Impact Score Display */}
                          <div 
                            className="flex items-center gap-1 px-3 py-1.5 bg-slate-900 text-white font-bold rounded-xl shadow-xs"
                            title="Formula: Score = (Severity Value * 20) + (Votes * 10) + (Confirmations * 15)"
                          >
                            <Flame size={13} className="text-orange-400 shrink-0 animate-pulse" />
                            <span>Impact: <span className="text-emerald-400 font-mono font-black">{issue.impactScore}</span></span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* AI Action button */}
                          {issue.aiAnalysis && (
                            <button
                              onClick={() => setExpandedAiId(isExpanded ? null : issue.id)}
                              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition cursor-pointer ${
                                isExpanded
                                  ? "bg-emerald-600 text-white"
                                  : "bg-emerald-50 text-emerald-700 border border-emerald-100 hover:bg-emerald-100"
                              }`}
                            >
                              <BrainCircuit size={13} />
                              AI Insights
                              {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                            </button>
                          )}

                          {/* Toggle Resolve (Only if logged in) */}
                          {currentUser && (
                            <button
                              onClick={() => onToggleResolve(issue.id)}
                              className={`p-1.5 rounded-xl border transition cursor-pointer ${
                                issue.isResolved
                                  ? "border-amber-200 text-amber-600 hover:bg-amber-50"
                                  : "border-slate-200 text-slate-500 hover:text-emerald-600 hover:bg-slate-50"
                              }`}
                              title={issue.isResolved ? "Reopen issue" : "Mark as resolved"}
                            >
                              <CheckCircle2 size={16} />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Collapsible AI Analysis Details */}
                  <AnimatePresence>
                    {isExpanded && issue.aiAnalysis && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="bg-emerald-50/40 border-t border-emerald-100/50 px-5 py-4 space-y-3"
                      >
                        <div className="flex items-start gap-2 text-xs font-bold text-emerald-800">
                          <BrainCircuit size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                          <span>MUNICIPAL RECOMMENDATIONS & METRICS</span>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                          {/* Recommendations */}
                          <div className="space-y-1 bg-white p-3 rounded-xl border border-emerald-100/30">
                            <span className="font-bold text-slate-700 block">Recommended Action Plan</span>
                            <p className="text-slate-600 leading-relaxed font-medium">
                              {issue.aiAnalysis.actionRequired}
                            </p>
                          </div>

                          {/* Classification parameters */}
                          <div className="space-y-2 bg-white p-3 rounded-xl border border-emerald-100/30 flex flex-col justify-between">
                            <div>
                              <span className="font-bold text-slate-700 block mb-1">AI Classification Criteria</span>
                              <div className="flex flex-wrap gap-1">
                                {issue.aiAnalysis.tags?.map((tag) => (
                                  <span key={tag} className="px-2 py-0.5 bg-slate-50 text-slate-600 rounded-md text-[10px] border border-slate-150">
                                    #{tag}
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div className="text-[10px] text-slate-400">
                              Assessed via Gemini Vision-flash model. Urgency ranking updated.
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
