export type SeverityLevel = "Low" | "Medium" | "High";

export interface AIAnalysis {
  title: string;
  description: string;
  severity: SeverityLevel;
  category: string;
  actionRequired: string;
  tags: string[];
}

export interface CivicIssue {
  id: string;
  title: string;
  description: string;
  image: string; // Base64 or placeholder URL
  category: string;
  severity: SeverityLevel;
  votes: number;
  confirmations: number;
  location: string;
  impactScore: number;
  reporterName: string;
  reportedAt: string;
  isResolved: boolean;
  upvotedBy: string[]; // List of user emails who upvoted
  confirmedBy: string[]; // List of user emails who confirmed the issue
  aiAnalysis?: AIAnalysis;
}

export interface User {
  email: string;
  username: string;
  avatarSeed: string;
}

export interface Stats {
  totalIssues: number;
  totalVotes: number;
  totalConfirmations: number;
  totalImpactScore: number;
  resolvedCount: number;
}
