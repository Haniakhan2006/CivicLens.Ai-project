import { useState, useEffect } from "react";
import { CivicIssue, User, Stats, SeverityLevel, AIAnalysis } from "./types";
import AuthModal from "./components/AuthModal";
import CommunityStats from "./components/CommunityStats";
import UploadForm from "./components/UploadForm";
import IssueDashboard from "./components/IssueDashboard";
import { Landmark, Sparkles, LogOut, ShieldCheck, Heart, User as UserIcon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [issues, setIssues] = useState<CivicIssue[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [stats, setStats] = useState<Stats>({
    totalIssues: 0,
    totalVotes: 0,
    totalConfirmations: 0,
    totalImpactScore: 0,
    resolvedCount: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [alert, setAlert] = useState<{ message: string; type: "success" | "error" } | null>(null);

  // 1. Load active user session and initial issue list
  useEffect(() => {
    // Current User Session
    const savedUser = localStorage.getItem("civiclens_current_user");
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (err) {
        console.error("Failed to parse saved user", err);
      }
    }

    // Load initial data
    fetchIssues();
  }, []);

  // 2. Automatically compute summary statistics when issues state updates
  useEffect(() => {
    if (issues.length === 0) {
      setStats({
        totalIssues: 0,
        totalVotes: 0,
        totalConfirmations: 0,
        totalImpactScore: 0,
        resolvedCount: 0,
      });
      return;
    }

    const totalIssues = issues.length;
    const totalVotes = issues.reduce((acc, curr) => acc + (curr.votes || 0), 0);
    const totalConfirmations = issues.reduce((acc, curr) => acc + (curr.confirmations || 0), 0);
    const totalImpactScore = issues.reduce((acc, curr) => acc + (curr.impactScore || 0), 0);
    const resolvedCount = issues.filter((i) => i.isResolved).length;

    setStats({
      totalIssues,
      totalVotes,
      totalConfirmations,
      totalImpactScore,
      resolvedCount,
    });
  }, [issues]);

  const triggerAlert = (message: string, type: "success" | "error") => {
    setAlert({ message, type });
    setTimeout(() => {
      setAlert(null);
    }, 4000);
  };

  const fetchIssues = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/issues");
      if (res.ok) {
        const data = await res.json();
        setIssues(data);
      } else {
        triggerAlert("Failed to load community issues from server.", "error");
      }
    } catch (err) {
      console.error(err);
      triggerAlert("Server connection error.", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    triggerAlert(`Signed in successfully as @${user.username}!`, "success");
  };

  const handleLogout = () => {
    localStorage.removeItem("civiclens_current_user");
    setCurrentUser(null);
    triggerAlert("Logged out of session.", "success");
  };

  // Submit new report to the backend Express API
  const handleReportIssue = async (issueData: {
    title: string;
    description: string;
    image: string;
    category: string;
    severity: SeverityLevel;
    location: string;
    aiAnalysis?: AIAnalysis;
  }) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }

    try {
      const res = await fetch("/api/issues", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...issueData,
          reporterName: currentUser.username,
        }),
      });

      if (res.ok) {
        const newIssue = await res.json();
        setIssues((prev) => [newIssue, ...prev]);
        triggerAlert("Civic issue successfully reported and added!", "success");
      } else {
        triggerAlert("Failed to file report.", "error");
      }
    } catch (err) {
      console.error(err);
      triggerAlert("Failed to connect to the server.", "error");
    }
  };

  // Toggle upvote on an issue
  const handleUpvote = async (issueId: string) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/issues/${issueId}/upvote`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: currentUser.email }),
      });

      if (res.ok) {
        const updatedIssue = await res.json();
        setIssues((prev) => prev.map((issue) => (issue.id === issueId ? updatedIssue : issue)));
        
        const hasVotedNow = updatedIssue.upvotedBy?.includes(currentUser.email);
        if (hasVotedNow) {
          triggerAlert("Upvote recorded!", "success");
        } else {
          triggerAlert("Upvote removed.", "success");
        }
      } else {
        triggerAlert("Failed to register vote.", "error");
      }
    } catch (err) {
      console.error(err);
      triggerAlert("Server connectivity failure.", "error");
    }
  };

  // Toggle citizen confirmation on an issue
  const handleConfirm = async (issueId: string) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/issues/${issueId}/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: currentUser.email }),
      });

      if (res.ok) {
        const updatedIssue = await res.json();
        setIssues((prev) => prev.map((issue) => (issue.id === issueId ? updatedIssue : issue)));
        
        const hasConfirmedNow = updatedIssue.confirmedBy?.includes(currentUser.email);
        if (hasConfirmedNow) {
          triggerAlert("Field presence confirmed! Impact score updated.", "success");
        } else {
          triggerAlert("Field confirmation retracted.", "success");
        }
      } else {
        triggerAlert("Failed to register confirmation.", "error");
      }
    } catch (err) {
      console.error(err);
      triggerAlert("Server connectivity failure.", "error");
    }
  };

  // Toggle issue resolution status
  const handleToggleResolve = async (issueId: string) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/issues/${issueId}/resolve`, {
        method: "POST",
      });

      if (res.ok) {
        const updatedIssue = await res.json();
        setIssues((prev) => prev.map((issue) => (issue.id === issueId ? updatedIssue : issue)));
        triggerAlert(
          updatedIssue.isResolved
            ? "Report successfully marked as RESOLVED! Excellent."
            : "Report reopened for municipal review.",
          "success"
        );
      } else {
        triggerAlert("Failed to update status.", "error");
      }
    } catch (err) {
      console.error(err);
      triggerAlert("Connectivity failure.", "error");
    }
  };

  const getAvatarEmoji = (seed: string) => {
    const avatars: Record<string, string> = {
      "avatar-1": "👷‍♂️",
      "avatar-2": "👩‍⚕️",
      "avatar-3": "🧑‍💻",
      "avatar-4": "👩‍🌾",
      "avatar-5": "👨‍🚒",
      "avatar-6": "👩‍🎓",
    };
    return avatars[seed] || "👤";
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans antialiased text-slate-800">
      {/* Toast Alert Banner */}
      <AnimatePresence>
        {alert && (
          <motion.div
            initial={{ opacity: 0, y: -20, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: -20, x: "-50%" }}
            className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full text-xs font-semibold shadow-lg border flex items-center gap-2 ${
              alert.type === "success"
                ? "bg-emerald-600 border-emerald-500 text-white"
                : "bg-rose-600 border-rose-500 text-white"
            }`}
          >
            <ShieldCheck size={14} />
            <span>{alert.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl text-white shadow-xs">
              <Landmark size={20} className="shrink-0" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-lg font-extrabold tracking-tight text-slate-900 leading-none">CivicLens</h1>
                <span className="text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 shrink-0">AI</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5 font-medium">Empowering neighborhood transparency</p>
            </div>
          </div>

          {/* Header Action / Profile */}
          <div className="flex items-center gap-3">
            {currentUser ? (
              <div id="user-profile-badge" className="flex items-center gap-2.5 bg-slate-50 border border-slate-150 rounded-full pl-2.5 pr-1.5 py-1 text-xs">
                <span className="text-base" role="img" aria-label="avatar">
                  {getAvatarEmoji(currentUser.avatarSeed)}
                </span>
                <span className="font-bold text-slate-700 truncate max-w-[120px]">
                  @{currentUser.username}
                </span>
                <button
                  onClick={handleLogout}
                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-full transition cursor-pointer"
                  title="Sign Out"
                >
                  <LogOut size={14} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsAuthOpen(true)}
                id="header-sign-in-btn"
                className="flex items-center gap-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 px-3.5 py-1.5 rounded-full shadow-xs cursor-pointer transition active:scale-98"
              >
                <UserIcon size={13} />
                Join Community
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Welcome section */}
      <section className="bg-gradient-to-b from-white to-transparent px-6 pt-6 pb-2">
        <div className="max-w-7xl mx-auto">
          <div className="bg-slate-900 rounded-2xl p-6 md:p-8 text-white relative overflow-hidden shadow-xs border border-slate-800/20">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-teal-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="relative max-w-2xl space-y-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/10 uppercase tracking-wider">
                <Sparkles size={11} /> Next-Gen Public Works
              </span>
              <h2 className="text-xl md:text-2xl font-black tracking-tight leading-tight">
                Inspect, report, and prioritize neighborhood repairs with Gemini Vision.
              </h2>
              <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-normal">
                Simply take a photo of any community hazard, potholes, or broken city fixtures. CivicLens AI automatically classifes gravity, recommends dispatch actions, and weighs scores using community upvotes to help public works team fix what matters first.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Body */}
      <main className="flex-1 px-6 py-4 max-w-7xl mx-auto w-full">
        {/* Statistics Banner */}
        <CommunityStats stats={stats} />

        {/* Dashboard grid layout */}
        <div id="main-content-grid" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form */}
          <div className="lg:col-span-4 xl:col-span-4">
            <UploadForm
              currentUser={currentUser}
              onOpenAuth={() => setIsAuthOpen(true)}
              onSubmitIssue={handleReportIssue}
            />
          </div>

          {/* Right Column: Dashboard */}
          <div className="lg:col-span-8 xl:col-span-8">
            {isLoading ? (
              <div className="bg-white rounded-2xl border border-slate-100 p-20 flex flex-col items-center justify-center text-center">
                <div className="w-8 h-8 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mb-3"></div>
                <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Loading dashboard reports...</span>
              </div>
            ) : (
              <IssueDashboard
                issues={issues}
                currentUser={currentUser}
                onUpvote={handleUpvote}
                onConfirm={handleConfirm}
                onToggleResolve={handleToggleResolve}
                onOpenAuth={() => setIsAuthOpen(true)}
              />
            )}
          </div>
        </div>
      </main>

      {/* Small clean footer */}
      <footer className="mt-12 border-t border-slate-150 py-6 px-6 bg-white text-center text-xs text-slate-400 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5">
            <Landmark size={14} className="text-slate-400" />
            <span>© 2026 CivicLens AI. Crafted for safe, beautiful neighborhoods.</span>
          </div>
          <div className="flex items-center gap-1 text-slate-300 hover:text-slate-500 transition">
            Made with <Heart size={11} className="text-rose-500 fill-rose-500 shrink-0" /> for community welfare
          </div>
        </div>
      </footer>

      {/* Auth Modal Container */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
}
