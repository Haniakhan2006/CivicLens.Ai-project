import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { CivicIssue, AIAnalysis, SeverityLevel } from "./src/types";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Body parser with 20MB limit for base64 image uploads
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ limit: "20mb", extended: true }));

// Initialize Gemini Client
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (geminiApiKey) {
  ai = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
  console.log("Gemini API successfully initialized on the server.");
} else {
  console.warn("WARNING: GEMINI_API_KEY is not set in environment. AI features will fallback to mock responses.");
}

// Helper function to calculate impact score and priority level
function calculateImpact(severity: SeverityLevel, votes: number, confirmations: number): number {
  const severityValue = severity === "High" ? 3 : severity === "Medium" ? 2 : 1;
  // Formula: Score = (Severity Value * 20) + (Votes * 10) + (Confirmations * 15)
  return (severityValue * 20) + (votes * 10) + (confirmations * 15);
}

// Mock database / In-memory store
let issues: CivicIssue[] = [
  {
    id: "issue-1",
    title: "Major Pothole on Main Street Crosswalk",
    description: "Deep pothole in the middle of the pedestrian crosswalk near the library. It causes cars to swerve suddenly into the oncoming lane and is a major tripping hazard for pedestrians at night.",
    image: "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=800&q=80",
    category: "Roads & Asphalt",
    severity: "High",
    votes: 24,
    confirmations: 12,
    location: "450 Main St (near Public Library)",
    impactScore: calculateImpact("High", 24, 12),
    reporterName: "Marcus Vance",
    reportedAt: new Date(Date.now() - 4 * 3600000).toISOString(), // 4 hours ago
    isResolved: false,
    upvotedBy: ["test@example.com"],
    confirmedBy: [],
    aiAnalysis: {
      title: "Major Pothole on Main Street Crosswalk",
      description: "Deep pothole in the middle of the pedestrian crosswalk near the library. It causes cars to swerve suddenly into the oncoming lane and is a major tripping hazard for pedestrians at night.",
      severity: "High",
      category: "Roads & Asphalt",
      actionRequired: "Immediate asphalt cold-patch repair to secure the pedestrian pathway and prevent vehicular damage.",
      tags: ["road-safety", "pothole", "pedestrian-hazard"]
    }
  },
  {
    id: "issue-2",
    title: "Overflowing Public Waste Bin",
    description: "Trash has accumulated around the public bin in Pioneer Park, attracting rodents. This is near the children's playground and creates sanitation and public health concerns.",
    image: "https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=800&q=80",
    category: "Sanitation",
    severity: "Medium",
    votes: 12,
    confirmations: 5,
    location: "Pioneer Park (North entrance near playground)",
    impactScore: calculateImpact("Medium", 12, 5),
    reporterName: "Elena Rostova",
    reportedAt: new Date(Date.now() - 12 * 3600000).toISOString(), // 12 hours ago
    isResolved: false,
    upvotedBy: [],
    confirmedBy: [],
    aiAnalysis: {
      title: "Overflowing Public Waste Bin",
      description: "Trash has accumulated around the public bin in Pioneer Park, attracting rodents. This is near the children's playground and creates sanitation and public health concerns.",
      severity: "Medium",
      category: "Sanitation",
      actionRequired: "Dispatch sanitation crew for bulk waste collection and inspect trash bin lid mechanics.",
      tags: ["garbage", "park-maintenance", "hygiene"]
    }
  },
  {
    id: "issue-3",
    title: "Flickering Streetlight on Oak Avenue",
    description: "The streetlamp is completely out or flashes intermittently, leaving a 50-meter stretch of sidewalk completely dark at night. Residents feel unsafe walking home.",
    image: "https://images.unsplash.com/photo-1509024644558-2f56ce76c490?auto=format&fit=crop&w=800&q=80",
    category: "Street Lighting",
    severity: "Low",
    votes: 6,
    confirmations: 2,
    location: "812 Oak Avenue (in front of Maple Apartments)",
    impactScore: calculateImpact("Low", 6, 2),
    reporterName: "Sarah Chen",
    reportedAt: new Date(Date.now() - 24 * 3600000).toISOString(), // 1 day ago
    isResolved: false,
    upvotedBy: [],
    confirmedBy: [],
    aiAnalysis: {
      title: "Flickering Streetlight on Oak Avenue",
      description: "The streetlamp is completely out or flashes intermittently, leaving a 50-meter stretch of sidewalk completely dark at night. Residents feel unsafe walking home.",
      severity: "Low",
      category: "Street Lighting",
      actionRequired: "Replace HPS bulb with energy-efficient LED fixture and inspect the local photodetector wiring.",
      tags: ["lighting", "neighborhood-safety", "infrastructure"]
    }
  }
];

// 1. API Endpoint: Get all issues
app.get("/api/issues", (req, res) => {
  res.json(issues);
});

// 2. API Endpoint: Add a new issue
app.post("/api/issues", (req, res) => {
  try {
    const { title, description, image, category, severity, location, reporterName, aiAnalysis } = req.body;

    if (!title || !category || !severity || !location) {
      return res.status(400).json({ error: "Missing required fields (title, category, severity, location)." });
    }

    const newIssue: CivicIssue = {
      id: `issue-${Date.now()}`,
      title,
      description: description || "",
      image: image || "https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=800&q=80", // placeholder
      category,
      severity,
      votes: 0,
      confirmations: 0,
      location,
      impactScore: calculateImpact(severity, 0, 0),
      reporterName: reporterName || "Anonymous Reporter",
      reportedAt: new Date().toISOString(),
      isResolved: false,
      upvotedBy: [],
      confirmedBy: [],
      aiAnalysis
    };

    issues.unshift(newIssue);
    res.status(201).json(newIssue);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. API Endpoint: Upvote an issue
app.post("/api/issues/:id/upvote", (req, res) => {
  try {
    const { id } = req.params;
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: "User email is required to upvote." });
    }

    const issue = issues.find((i) => i.id === id);
    if (!issue) {
      return res.status(404).json({ error: "Issue not found." });
    }

    const upvoteIndex = issue.upvotedBy.indexOf(email);
    if (upvoteIndex > -1) {
      issue.upvotedBy.splice(upvoteIndex, 1);
      issue.votes = Math.max(0, issue.votes - 1);
    } else {
      issue.upvotedBy.push(email);
      issue.votes += 1;
    }

    issue.impactScore = calculateImpact(issue.severity, issue.votes, issue.confirmations);

    res.json(issue);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3.5. API Endpoint: Confirm existence of an issue
app.post("/api/issues/:id/confirm", (req, res) => {
  try {
    const { id } = req.params;
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: "User email is required to confirm." });
    }

    const issue = issues.find((i) => i.id === id);
    if (!issue) {
      return res.status(404).json({ error: "Issue not found." });
    }

    const confirmIndex = issue.confirmedBy.indexOf(email);
    if (confirmIndex > -1) {
      issue.confirmedBy.splice(confirmIndex, 1);
      issue.confirmations = Math.max(0, issue.confirmations - 1);
    } else {
      issue.confirmedBy.push(email);
      issue.confirmations += 1;
    }

    issue.impactScore = calculateImpact(issue.severity, issue.votes, issue.confirmations);

    res.json(issue);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4. API Endpoint: Resolve/Toggle resolve an issue
app.post("/api/issues/:id/resolve", (req, res) => {
  try {
    const { id } = req.params;
    const issue = issues.find((i) => i.id === id);
    if (!issue) {
      return res.status(404).json({ error: "Issue not found." });
    }

    issue.isResolved = !issue.isResolved;
    res.json(issue);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 5. API Endpoint: Analyze civic issue image via Gemini
app.post("/api/analyze-image", async (req, res) => {
  try {
    const { base64Image, mimeType } = req.body;

    if (!base64Image || !mimeType) {
      return res.status(400).json({ error: "Missing base64Image or mimeType in request body." });
    }

    if (!ai) {
      // Fallback if no API key is set
      console.log("No Gemini API key available. Returning high-quality mock analysis.");
      const mockAnalysis: AIAnalysis = {
        title: "Pothole / Road Degradation",
        description: "An automatic visual assessment suggests a substantial pavement defect. This crater is a safety risk for light vehicles, bicycles, and unsuspecting pedestrians.",
        severity: "Medium",
        category: "Roads & Asphalt",
        actionRequired: "Repave damaged localized asphalt section and check subgrade compaction.",
        tags: ["roadwork", "safety-alert", "pavement"]
      };
      return res.json(mockAnalysis);
    }

    // Strip out header if present (e.g. "data:image/jpeg;base64,")
    const cleanBase64 = base64Image.replace(/^data:image\/\w+;base64,/, "");

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: cleanBase64,
      },
    };

    const textPart = {
      text: `You are CivicLens AI, an urban planner and civil infrastructure inspector. 
Analyze this image of a civic/urban issue (e.g. pothole, graffiti, street litter, broken sign, leaking pipe, dark streetlight, hazard, sidewalk crack).
Provide a structured analysis inside the response schema, including:
1. 'title': A clean, professional, concise description (max 6 words).
2. 'description': A clear explanation of what is shown and why it is a nuisance or hazard to citizens.
3. 'severity': Classify as "Low", "Medium", or "High" depending on safety risk and immediate threat.
4. 'category': Choose a fitting public work category (e.g., 'Roads & Asphalt', 'Sanitation', 'Street Lighting', 'Public Parks', 'Water & Sewer', 'Hazards', 'Public Facilities').
5. 'actionRequired': Suggest a specific action item for municipal repair crews.
6. 'tags': Provide 2 to 3 concise relevant tags.`,
    };

    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING, description: "Professional short title of the civic issue" },
        description: { type: Type.STRING, description: "Detailed summary of the issue and hazard details" },
        severity: { type: Type.STRING, enum: ["Low", "Medium", "High"], description: "Urgency and hazard ranking" },
        category: { type: Type.STRING, description: "Municipal public works category" },
        actionRequired: { type: Type.STRING, description: "Direct repair recommendation for city crews" },
        tags: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "2-3 short lowercase tags"
        }
      },
      required: ["title", "description", "severity", "category", "actionRequired", "tags"]
    };

    console.log("Calling Gemini 3.5 Flash to analyze uploaded civic image...");
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2,
      },
    });

    const textResult = response.text;
    if (!textResult) {
      throw new Error("Empty response received from Gemini.");
    }

    const parsedResponse = JSON.parse(textResult.trim()) as AIAnalysis;
    console.log("Analysis completed successfully:", parsedResponse.title);
    res.json(parsedResponse);
  } catch (error: any) {
    console.error("Gemini Image Analysis failed:", error);
    res.status(500).json({ error: "AI analysis failed: " + error.message });
  }
});

// Configure Vite middleware or serve static files
async function startServer() {
  const isProd = process.env.NODE_ENV === "production";
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Bind to port 3000 and 0.0.0.0 (required)
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CivicLens AI backend running on http://localhost:${PORT}`);
  });
}

startServer();
